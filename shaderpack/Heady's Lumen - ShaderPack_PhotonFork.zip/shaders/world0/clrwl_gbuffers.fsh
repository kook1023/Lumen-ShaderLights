#version 400 compatibility
#define WORLD_OVERWORLD
#define PROGRAM_GBUFFERS_TERRAIN
#define PROGRAM_GBUFFERS_BLOCK
#define PROGRAM_GBUFFERS_ENTITIES
#define COLORWHEEL
#define fsh
#include "/program/gbuffers_all_solid.fsh"
