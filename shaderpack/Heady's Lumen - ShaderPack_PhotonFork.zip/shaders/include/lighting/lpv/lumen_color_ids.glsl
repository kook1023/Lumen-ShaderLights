#if !defined INCLUDE_LIGHTING_LPV_LUMEN_COLOR_IDS
#define INCLUDE_LIGHTING_LPV_LUMEN_COLOR_IDS

// LUMEN: the light table from Heady's Lumen: ShaderLights.
// The mod gives a placed block that needs your exact colour, intensity or flicker the block id 10000 + 1024 + row,
// so material ids from 1024 to 17407 are rows of the light table, a small texture the mod keeps up to date
// (customTexture.lumen_light_table in shaders.properties). Each row (3 texels at x = row % 128 * 3, y = row / 128):
//   texel 0: R,G = the block's own block.properties id (low, high byte)   B = flags: 1 custom colour, 2 flicker
//   texel 1: R,G,B = custom colour
//   texel 2: R = intensity 1-15, G = flicker speed 1-20, B = flicker strength 0-100 (percent)
// Everything except the light it gives uses the block's own id, so a placed torch is still a torch.
// The last texel (383, 127) holds the signature "LUM". Without it (no mod, an older mod, or Iris did not bind the
// texture) every id from 1024 up is treated as a plain torch, so nothing breaks.
uniform sampler2D lumen_light_table;

const uint lumen_table_base = 1024u;
const uint lumen_table_end  = 1024u + 16384u;
const uint lumen_transparent_flag = 0x8000u; // in the light volume: "light passes through" (Photon used +128)

bool lumen_is_table_id(uint id) { return lumen_table_base <= id && id < lumen_table_end; }

uvec4 lumen_texel(uint id, int k) {
    int row = int(id - lumen_table_base);
    vec4 t = texelFetch(lumen_light_table, ivec2((row % 128) * 3 + k, row / 128), 0);
    return uvec4(t * 255.0 + 0.5);
}

bool lumen_table_ready() {
    uvec3 s = uvec3(texelFetch(lumen_light_table, ivec2(383, 127), 0).rgb * 255.0 + 0.5);
    return s == uvec3(76u, 85u, 77u);
}

// Photon's material id for the block (its block.properties id minus 10000)
uint lumen_material(uint id) {
    if (!lumen_table_ready()) return 36u; // torch
    uvec4 t = lumen_texel(id, 0);
    uint pack_id = t.r | (t.g << 8u);
    return pack_id >= 10000u ? pack_id - 10000u : 0u;
}

bool lumen_has_color(uint id) { return lumen_table_ready() && (lumen_texel(id, 0).b & 1u) != 0u; }
bool lumen_flickers(uint id)  { return lumen_table_ready() && (lumen_texel(id, 0).b & 2u) != 0u; }
vec3 lumen_color(uint id)     { return vec3(lumen_texel(id, 1).rgb) / 255.0; }
float lumen_level(uint id)    { return float(lumen_texel(id, 2).r); }

// Flame-like flicker: smooth random noise, squared so the light stays near full brightness and dips now and then.
// world_pos keeps lights out of step. Speed and strength come from the row (the mod's sliders).
float lumen_hash(float n) { return fract(sin(n) * 43758.5453); }

float lumen_noise(float t, float seed) {
    float i = floor(t);
    float f = t - i;
    float u = f * f * (3.0 - 2.0 * f);
    return mix(lumen_hash(i + seed), lumen_hash(i + 1.0 + seed), u);
}

float lumen_flicker(uint id, float time, vec3 world_pos) {
    uvec4 t = lumen_texel(id, 2);
    float seed = fract(dot(world_pos, vec3(0.1031, 0.11369, 0.13787))) * 1000.0;
    float x = time * float(t.g);
    float n = 0.65 * lumen_noise(x, seed) + 0.35 * lumen_noise(x * 2.7 + 17.3, seed + 31.7);
    return 1.0 - (float(t.b) / 100.0) * clamp(n * n, 0.0, 1.0);
}

#endif
